/*******************************************************************************
* File Name: Sqr.c  
* Version 2.20
*
* Description:
*  This file contains APIs to set up the Pins component for low power modes.
*
* Note:
*
********************************************************************************
* Copyright 2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "cytypes.h"
#include "Sqr.h"

static Sqr_BACKUP_STRUCT  Sqr_backup = {0u, 0u, 0u};


/*******************************************************************************
* Function Name: Sqr_Sleep
****************************************************************************//**
*
* \brief Stores the pin configuration and prepares the pin for entering chip 
*  deep-sleep/hibernate modes. This function applies only to SIO and USBIO pins.
*  It should not be called for GPIO or GPIO_OVT pins.
*
* <b>Note</b> This function is available in PSoC 4 only.
*
* \return 
*  None 
*  
* \sideeffect
*  For SIO pins, this function configures the pin input threshold to CMOS and
*  drive level to Vddio. This is needed for SIO pins when in device 
*  deep-sleep/hibernate modes.
*
* \funcusage
*  \snippet Sqr_SUT.c usage_Sqr_Sleep_Wakeup
*******************************************************************************/
void Sqr_Sleep(void)
{
    #if defined(Sqr__PC)
        Sqr_backup.pcState = Sqr_PC;
    #else
        #if (CY_PSOC4_4200L)
            /* Save the regulator state and put the PHY into suspend mode */
            Sqr_backup.usbState = Sqr_CR1_REG;
            Sqr_USB_POWER_REG |= Sqr_USBIO_ENTER_SLEEP;
            Sqr_CR1_REG &= Sqr_USBIO_CR1_OFF;
        #endif
    #endif
    #if defined(CYIPBLOCK_m0s8ioss_VERSION) && defined(Sqr__SIO)
        Sqr_backup.sioState = Sqr_SIO_REG;
        /* SIO requires unregulated output buffer and single ended input buffer */
        Sqr_SIO_REG &= (uint32)(~Sqr_SIO_LPM_MASK);
    #endif  
}


/*******************************************************************************
* Function Name: Sqr_Wakeup
****************************************************************************//**
*
* \brief Restores the pin configuration that was saved during Pin_Sleep(). This 
* function applies only to SIO and USBIO pins. It should not be called for
* GPIO or GPIO_OVT pins.
*
* For USBIO pins, the wakeup is only triggered for falling edge interrupts.
*
* <b>Note</b> This function is available in PSoC 4 only.
*
* \return 
*  None
*  
* \funcusage
*  Refer to Sqr_Sleep() for an example usage.
*******************************************************************************/
void Sqr_Wakeup(void)
{
    #if defined(Sqr__PC)
        Sqr_PC = Sqr_backup.pcState;
    #else
        #if (CY_PSOC4_4200L)
            /* Restore the regulator state and come out of suspend mode */
            Sqr_USB_POWER_REG &= Sqr_USBIO_EXIT_SLEEP_PH1;
            Sqr_CR1_REG = Sqr_backup.usbState;
            Sqr_USB_POWER_REG &= Sqr_USBIO_EXIT_SLEEP_PH2;
        #endif
    #endif
    #if defined(CYIPBLOCK_m0s8ioss_VERSION) && defined(Sqr__SIO)
        Sqr_SIO_REG = Sqr_backup.sioState;
    #endif
}


/* [] END OF FILE */
