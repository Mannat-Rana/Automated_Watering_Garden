/*******************************************************************************
* File Name: intpin.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_intpin_H) /* Pins intpin_H */
#define CY_PINS_intpin_H

#include "cytypes.h"
#include "cyfitter.h"
#include "intpin_aliases.h"


/***************************************
*     Data Struct Definitions
***************************************/

/**
* \addtogroup group_structures
* @{
*/
    
/* Structure for sleep mode support */
typedef struct
{
    uint32 pcState; /**< State of the port control register */
    uint32 sioState; /**< State of the SIO configuration */
    uint32 usbState; /**< State of the USBIO regulator */
} intpin_BACKUP_STRUCT;

/** @} structures */


/***************************************
*        Function Prototypes             
***************************************/
/**
* \addtogroup group_general
* @{
*/
uint8   intpin_Read(void);
void    intpin_Write(uint8 value);
uint8   intpin_ReadDataReg(void);
#if defined(intpin__PC) || (CY_PSOC4_4200L) 
    void    intpin_SetDriveMode(uint8 mode);
#endif
void    intpin_SetInterruptMode(uint16 position, uint16 mode);
uint8   intpin_ClearInterrupt(void);
/** @} general */

/**
* \addtogroup group_power
* @{
*/
void intpin_Sleep(void); 
void intpin_Wakeup(void);
/** @} power */


/***************************************
*           API Constants        
***************************************/
#if defined(intpin__PC) || (CY_PSOC4_4200L) 
    /* Drive Modes */
    #define intpin_DRIVE_MODE_BITS        (3)
    #define intpin_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - intpin_DRIVE_MODE_BITS))

    /**
    * \addtogroup group_constants
    * @{
    */
        /** \addtogroup driveMode Drive mode constants
         * \brief Constants to be passed as "mode" parameter in the intpin_SetDriveMode() function.
         *  @{
         */
        #define intpin_DM_ALG_HIZ         (0x00u) /**< \brief High Impedance Analog   */
        #define intpin_DM_DIG_HIZ         (0x01u) /**< \brief High Impedance Digital  */
        #define intpin_DM_RES_UP          (0x02u) /**< \brief Resistive Pull Up       */
        #define intpin_DM_RES_DWN         (0x03u) /**< \brief Resistive Pull Down     */
        #define intpin_DM_OD_LO           (0x04u) /**< \brief Open Drain, Drives Low  */
        #define intpin_DM_OD_HI           (0x05u) /**< \brief Open Drain, Drives High */
        #define intpin_DM_STRONG          (0x06u) /**< \brief Strong Drive            */
        #define intpin_DM_RES_UPDWN       (0x07u) /**< \brief Resistive Pull Up/Down  */
        /** @} driveMode */
    /** @} group_constants */
#endif

/* Digital Port Constants */
#define intpin_MASK               intpin__MASK
#define intpin_SHIFT              intpin__SHIFT
#define intpin_WIDTH              1u

/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in intpin_SetInterruptMode() function.
     *  @{
     */
        #define intpin_INTR_NONE      ((uint16)(0x0000u)) /**< \brief Disabled             */
        #define intpin_INTR_RISING    ((uint16)(0x5555u)) /**< \brief Rising edge trigger  */
        #define intpin_INTR_FALLING   ((uint16)(0xaaaau)) /**< \brief Falling edge trigger */
        #define intpin_INTR_BOTH      ((uint16)(0xffffu)) /**< \brief Both edge trigger    */
    /** @} intrMode */
/** @} group_constants */

/* SIO LPM definition */
#if defined(intpin__SIO)
    #define intpin_SIO_LPM_MASK       (0x03u)
#endif

/* USBIO definitions */
#if !defined(intpin__PC) && (CY_PSOC4_4200L)
    #define intpin_USBIO_ENABLE               ((uint32)0x80000000u)
    #define intpin_USBIO_DISABLE              ((uint32)(~intpin_USBIO_ENABLE))
    #define intpin_USBIO_SUSPEND_SHIFT        CYFLD_USBDEVv2_USB_SUSPEND__OFFSET
    #define intpin_USBIO_SUSPEND_DEL_SHIFT    CYFLD_USBDEVv2_USB_SUSPEND_DEL__OFFSET
    #define intpin_USBIO_ENTER_SLEEP          ((uint32)((1u << intpin_USBIO_SUSPEND_SHIFT) \
                                                        | (1u << intpin_USBIO_SUSPEND_DEL_SHIFT)))
    #define intpin_USBIO_EXIT_SLEEP_PH1       ((uint32)~((uint32)(1u << intpin_USBIO_SUSPEND_SHIFT)))
    #define intpin_USBIO_EXIT_SLEEP_PH2       ((uint32)~((uint32)(1u << intpin_USBIO_SUSPEND_DEL_SHIFT)))
    #define intpin_USBIO_CR1_OFF              ((uint32)0xfffffffeu)
#endif


/***************************************
*             Registers        
***************************************/
/* Main Port Registers */
#if defined(intpin__PC)
    /* Port Configuration */
    #define intpin_PC                 (* (reg32 *) intpin__PC)
#endif
/* Pin State */
#define intpin_PS                     (* (reg32 *) intpin__PS)
/* Data Register */
#define intpin_DR                     (* (reg32 *) intpin__DR)
/* Input Buffer Disable Override */
#define intpin_INP_DIS                (* (reg32 *) intpin__PC2)

/* Interrupt configuration Registers */
#define intpin_INTCFG                 (* (reg32 *) intpin__INTCFG)
#define intpin_INTSTAT                (* (reg32 *) intpin__INTSTAT)

/* "Interrupt cause" register for Combined Port Interrupt (AllPortInt) in GSRef component */
#if defined (CYREG_GPIO_INTR_CAUSE)
    #define intpin_INTR_CAUSE         (* (reg32 *) CYREG_GPIO_INTR_CAUSE)
#endif

/* SIO register */
#if defined(intpin__SIO)
    #define intpin_SIO_REG            (* (reg32 *) intpin__SIO)
#endif /* (intpin__SIO_CFG) */

/* USBIO registers */
#if !defined(intpin__PC) && (CY_PSOC4_4200L)
    #define intpin_USB_POWER_REG       (* (reg32 *) CYREG_USBDEVv2_USB_POWER_CTRL)
    #define intpin_CR1_REG             (* (reg32 *) CYREG_USBDEVv2_CR1)
    #define intpin_USBIO_CTRL_REG      (* (reg32 *) CYREG_USBDEVv2_USB_USBIO_CTRL)
#endif    
    
    
/***************************************
* The following code is DEPRECATED and 
* must not be used in new designs.
***************************************/
/**
* \addtogroup group_deprecated
* @{
*/
#define intpin_DRIVE_MODE_SHIFT       (0x00u)
#define intpin_DRIVE_MODE_MASK        (0x07u << intpin_DRIVE_MODE_SHIFT)
/** @} deprecated */

#endif /* End Pins intpin_H */


/* [] END OF FILE */
